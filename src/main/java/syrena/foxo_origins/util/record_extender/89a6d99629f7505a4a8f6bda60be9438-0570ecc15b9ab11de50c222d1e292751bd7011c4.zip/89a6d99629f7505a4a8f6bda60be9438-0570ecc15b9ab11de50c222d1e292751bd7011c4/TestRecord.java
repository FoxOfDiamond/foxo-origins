package io.github.cputnama11y.chickens.utils;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;

public record TestRecord() {
    public static final Codec<TestRecord> CODEC = MapCodec.unitCodec(TestRecord::new);

}
