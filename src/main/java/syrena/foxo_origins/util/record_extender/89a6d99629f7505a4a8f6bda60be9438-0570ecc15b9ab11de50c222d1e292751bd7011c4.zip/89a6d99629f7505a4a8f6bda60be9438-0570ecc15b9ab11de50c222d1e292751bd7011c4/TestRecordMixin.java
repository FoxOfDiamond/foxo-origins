package io.github.cputnama11y.chickens.mixin;

import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.MapCodec;
import io.github.cputnama11y.chickens.utils.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(TestRecord.class)
public class TestRecordMixin {
    private final MergedRecord ours = MergedRecord.CTOR_PARAM.orElse(/* default values*/ new MergedRecord(0, 0));
    @Shadow
    public static Codec<TestRecord> CODEC;

    static {
        var originalCodec = CODEC;
        CODEC = MergedRecord.CODEC.dispatch(test -> ((TestRecordMixin) (Object) test).ours, ours -> new ScopedValueComposeMapCodec<>(new HashDivergentMapCodec<>(
                MapCodec.assumeMapUnsafe(originalCodec),
                new OpsSwitchMapCodec<>(JsonOps.INSTANCE, MapCodec.assumeMapUnsafe(originalCodec))
        ), MergedRecord.CTOR_PARAM, ours));
    }
}
