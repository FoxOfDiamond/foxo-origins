This file lists all the changes made to the base origins for the rework.

### Arachnid
- The 'Carnivore' power now has an actionbar indicator when preventing a player from consuming non-meat foodstuff.
- The 'Climbing' power now has an actionbar indicator for toggling its state.
- The 'Webbing' power is now an active power (currently triggered with the `key.saveToolbarActivator` keybinding) and projectile-based with a 100 ticks cooldown.

### Avian
- The 'Vegetarian' power now has an actionbar indicator when preventing a player from consuming meat foodstuff.
- The 'Like Air' power is slightly different, where it now uses the `neo-apoli:modify/air/speed` power type to modify the entity's flying speed based on its `minecraft:movement_speed` attribute.

### Blazeborne
- It can now be damaged by splash potions.
- Its 'Water Vulnerability' power now has a 20 ticks cooldown and an overlay which color is biome-dependent.

### Elytrian
- Its 'Launch' power now applies Z-forward local velocity when the player is fall flying, also spawning particles continuously for 40 ticks.
- Its 'Launch' power can be currently triggered with the `key.saveToolbarActivator` keybinding.
- Its 'Aerial Combatant' power's damage bonus is now dependent on the player's magnitude of its velocity multiplied by 0.9, with a max cap. of 200%.
- The parameters of its 'Claustrophobia' power (stacks, min stacks, max stacks, duration per stack) can now be modified via `/data modify ... neo-apoli:power` command.

### Enderian
- It can now be damaged by splash potions.
- Its 'Water Vulnerability' power now has an overlay which color is biome-dependent.
- Its 'Pumpkin Hate' power now only makes an entity wearing the pumpkin more transparent the further away they are, with a maximum of 4 blocks (they will be visually invisible beyond 4 blocks.)
- Its 'Teleportation' power can be currently triggered with the `key.saveToolbarActivator` keybinding.

### Feline
The following powers are currently missing due to power types not being re-implemented yet:
- 'Scare Creepers'
- 'Cat Vision'
- 'Velvet Paws'

### Merling
- It now spawns in a biome considered 'aquatic' (included in the `#c:is_aquatic` biome tag.)
- The following powers are currently missing due to power types or needed attributes that aren't re-implemented yet or missing:
  - 'Gills'
  - 'Wet Eyes'
  - 'Fins'
  - 'Conduit Power on Land'
  - 'Like Water'

### Phantom
- The overlay for its 'Phasing' power is now [dynamically] dependent on the player's food level.
- Its 'Phasing' power can be currently toggled with the `key.saveToolbarActivator` keybinding.
