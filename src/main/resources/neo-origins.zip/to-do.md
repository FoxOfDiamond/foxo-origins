### Enderian
- Add a power type for modifying ARGB of feature renderers/render layers for its 'Pumpkin Hate' power.

### Feline
- Add a power type for adding goals? to entities/creepers for its 'Scare Creepers' power.
- Add a power type for providing customizable night vision for its 'Cat Vision' power.
- Add a power type for preventing emission of game events for its 'Velvet Paws' power.

### Merling
- Add a library that adds additional attributes for its 'Wet Eyes' and 'Fins' power.
- Add a power type for customizing breathable blocks for its 'Gills' power.
- Add a power type for enabling the conduit effect on land for its 'Conduit Power on Land' power.
- Add a power type for preventing the entity from sinking underwater for its 'Like Water' power.